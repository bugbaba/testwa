import sys
import requests
import argparse
from urllib import parse
import concurrent.futures
import warnings
warnings.filterwarnings('ignore')

headers = {
	'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
}

parser = argparse.ArgumentParser()

parser.add_argument(
	'-u', '--url',
	help='URL target',
	type=str,
	dest='url',
	default=None
)

parser.add_argument(
	'-f', '--file',
	help='file with targets',
	type=str,
	dest='furls',
	default=None
)

parser.add_argument(
	'-p', '--payload',
	help='Define payload',
	type=str,
	dest='payload',
	default="</bc_3"
)

parser.add_argument(
	'-o', '--output',
	help='output filename',
	type=str,
	dest='output_filename',
)

parser.add_argument(
	'-t', '--thread',
	help='thread count',
	type=int,
	dest='thread_count',
	default="10"
)

args = parser.parse_args()

if (args.url is None) and (args.furls is None):
	parser.print_help()
	sys.exit(1)

url = args.url
payload = args.payload
black_list = []

def main():

	if args.furls:
		print("[!] File Mode")
		main_list = open(args.furls).read().splitlines()
		with concurrent.futures.ThreadPoolExecutor(max_workers=args.thread_count) as executor:
			threadpool = (executor.submit(fast_attack, url) for url in main_list)

			for future in concurrent.futures.as_completed(threadpool):
				pass

	else:
		print("[!] single URL Mode")
		urlparsed = parse.urlparse(args.url)
		parameters_in_url = parse.parse_qsl(urlparsed.query)
		# parameterkey_in_url = parse.parse_qs(urlparsed.query)
		scheme = urlparsed.scheme
		target = urlparsed.netloc
		path = urlparsed.path
		baseUrl = "{}://{}{}".format(scheme, target, path)
		#addFoundParameterToTestset(customParameters, parameterkey_in_url, parameters_in_url)

		showSimpleProcessData(baseUrl, parameters_in_url, path, scheme, target)
		testUrlParams = prepareTestUrls(baseUrl, parameters_in_url)

		requestUrlAndCheckForReflection(testUrlParams)

	print("Process finished")


def requestUrlAndCheckForReflection(testUrlParams, target):
	for testparam, testUrl in testUrlParams:
		try:
			res = requests.get(testUrl, headers=headers, verify=False, timeout=10, allow_redirects=True)

			print("Testing: {}".format(testUrl))
			print("\033[92mStatus:\033[0m {}".format(res.status_code))

			if res.status_code == 429:
				black_list.append(target)

			if 'application/json' in res.headers['Content-Type']:
				# print("Response content-type is Json")
				quit()

			if 'application/javascript' in res.headers['Content-Type']:
				# print("Response content-type is javascript")
				quit()

			if payload in res.text:
				black_list.append(target)
				print(" \033[33;1mParam:\033[0m {}".format(testparam))
				print(" \033[33;1mFinal report:\033[0m {}".format(testUrl))
				if args.output_filename:
					with open(args.output_filename, 'a+') as f:
						f.write(testUrl +"\r\n")

		except Exception as e:
			print(e)
			print("Exception was thrown...")

		print("")


def showSimpleProcessData(baseUrl, parameters_in_url, path, scheme, target):
	print("\033[92mURL:\033[0m {}".format(baseUrl))
	print("")
	print("\033[92mThese parameters will be tested:\033[0m  ")
	for param, value in parameters_in_url:
		textAddon = ""
		print("\033[94m{}\033[0m [{}] {}".format(param, value, textAddon))

	print("")


def prepareTestUrls(baseUrl, parameters_in_url):
	manipulated = []
	testUrlParams = []

	for param1, value1 in parameters_in_url:
		testparam = ''
		testurl = baseUrl

		if param1 in manipulated:
			tmptesturl = testurl + "?" + param1 + "[" + payload + "]" + "=" + param1
			testurl = testurl + "?" + param1 + "=" + value1

		else:
			testparam = param1
			tmptesturl = testurl + "?" + param1 + "[" + payload + "]" + "=" + param1
			testurl = testurl + "?" + param1 + "=" + payload
			manipulated.append(param1)

		for param2, value2 in parameters_in_url:
			if param1 is param2:
				continue

			testurl = testurl + "&" + param2 + "=" + value2

		testUrlParams.append([testparam, testurl])
		# testUrlParams.append([testparam, tmptesturl])

	return testUrlParams


def fast_attack(url):
	# print("dbg", url)
	urlparsed = parse.urlparse(url)
	parameters_in_url = parse.parse_qsl(urlparsed.query)
	scheme = urlparsed.scheme
	target = urlparsed.netloc
	path = urlparsed.path
	baseUrl = "{}://{}{}".format(scheme, target, path)
	if target not in black_list:
		#showSimpleProcessData(baseUrl, parameters_in_url, path, scheme, target)
		testUrlParams = prepareTestUrls(baseUrl, parameters_in_url)
		requestUrlAndCheckForReflection(testUrlParams, target)
	else:
		print(target, "already vuln")

if __name__ == '__main__':
	main()
